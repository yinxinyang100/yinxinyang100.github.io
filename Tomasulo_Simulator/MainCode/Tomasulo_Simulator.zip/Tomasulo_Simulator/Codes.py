from tkinter import filedialog, BooleanVar
from tkinter.messagebox import showerror, showinfo
from tkinter.simpledialog import askinteger, askstring
from typing import Union
import re

class Codes():
    def __init__(self, root):
        self.CodingStart = {'LD':   self.LD,
                            'SD':   self.SD,
                            'ADD':  self.ADD,
                            'SUB':  self.SUB,
                            'MUL':  self.MUL,
                            'DIV':  self.DIV}
        self.root = root
        
        self.time = 0
        self.ReadParts = []
        self.stalls = {
            'RAW': 0,
            'WAR': 0,
            'Structural': 0
        }
        self.Conditional_Branches = {
            'taken': 0,
            'not taken': 0
        }
        self.Load_Store_Instructions = {
            'Loads': 0,
            'Stores': 0
        }
        self.Coding = []
        self.RS = {}
        self.PartNum = {
            'LD': 3,
            'ADD': 3,
            'MUL': 2
        }
        self.PartTime = {
            'LD': 2,
            'SD': 1,
            'ADD': 2,
            'SUB': 2,
            'MUL': 7,
            'DIV': 10
        }
        self.Qi = {}
        self.Run_executed_num = 0
        
        self.filepath = None
        self.fileread = []
        self.isCode = False
        self.endflag = False
        self.Tags = {}
        self.Breakpoints = {}
        self.Data = {}
        self.HistoryData = []
        self.Regs = {}
        self.HistoryRegs = []
        self.TASKS = []
        self.HistoryTASKS = []

        self.DebugText = None
        self.StatisticsText = None
        self.ReservationText = None
        self.LoadStoreText = None
        self.ClockText = None
        self.RegisterText = None
        self.CodeText = None
        
        self.Regs['PC'] = 0
        for i in range(32):
            self.Regs['r'+str(i)] = 0
        
        for item in ['LD', 'ADD', 'MUL']:
            for i in range(self.PartNum[item]):
                self.RS[item + str(i+1)] = {
                    'Busy': 'No',
                    'Op': '',
                    'Result': '',
                    'time': '',
                    'Qj': '',
                    'Vj': '',
                    'Qk': '',
                    'Vk': ''
                }
    
    def reset(self, filepath=None, fileread=[], Breakpoints={}, DebugText=None, StatisticsText=None, ReservationText=None, LoadStoreText=None, ClockText=None, RegisterText=None, CodeText=None):
        self.time = 0
        self.ReadParts = []
        self.stalls = {
            'RAW': 0,
            'WAR': 0,
            'Structural': 0
        }
        self.Conditional_Branches = {
            'taken': 0,
            'not taken': 0
        }
        self.Load_Store_Instructions = {
            'Loads': 0,
            'Stores': 0
        }
        self.Coding = []
        self.RS = {}
        self.Qi = {}
        self.Run_executed_num = 0
        self.filepath = filepath
        self.fileread = fileread
        self.isCode = False
        self.endflag = False
        self.Tags = {}
        self.Breakpoints = Breakpoints
        self.Data = {}
        self.HistoryData = []
        self.Regs = {}
        self.HistoryRegs = []
        self.TASKS = []
        self.HistoryTASKS = []
        
        if self.DebugText != None:
            self.DebugText.delete('1.0', 'end')
        if self.StatisticsText != None:
            self.StatisticsText.delete('1.0', 'end')
        if self.ReservationText != None:
            self.ReservationText.delete('1.0', 'end')
        if self.LoadStoreText != None:
            self.LoadStoreText.delete('1.0', 'end')
        if self.ClockText != None:
            self.ClockText.delete('1.0', 'end')
        if self.RegisterText != None:
            self.RegisterText.delete('1.0', 'end')
        if self.CodeText != None:
            self.CodeText.delete('1.0', 'end')
        self.DebugText = DebugText
        self.StatisticsText = StatisticsText
        self.ReservationText = ReservationText
        self.LoadStoreText = LoadStoreText
        self.ClockText = ClockText
        self.RegisterText = RegisterText
        self.CodeText = CodeText

        self.Regs['PC'] = 0
        for i in range(32):
            self.Regs['r'+str(i)] = 0
        
        for item in ['LD', 'ADD', 'MUL']:
            for i in range(self.PartNum[item]):
                self.RS[item + str(i+1)] = {
                    'Busy': 'No',
                    'Op': '',
                    'Result': '',
                    'time': '',
                    'Qj': '',
                    'Vj': '',
                    'Qk': '',
                    'Vk': ''
                }
    
    def reset_DLX(self) -> bool:
        self.reset(self.filepath, self.fileread, self.Breakpoints, self.DebugText, self.StatisticsText, self.ReservationText, self.LoadStoreText, self.ClockText, self.RegisterText, self.CodeText)
        try:
            self.DebugText.insert('end', 'Loading For ' + self.filepath + ' ... ' + '\n\n')
            f = self.fileread
            for line in f:
                self.DebugText.insert('end', line.strip() + '\n')
                if(line.strip() == ''):
                    continue
                self.CheckCoding(line.strip())
            self.HistoryData.append(self.Data)
            self.HistoryRegs.append(self.Regs)
            self.HistoryTASKS.append(self.TASKS)
            self.DebugText.insert('end', '\nLoading Finished!' + '\n')
            self.ShowState(0)
            return True
        except:
            return False

    def CheckCoding(self, code: str):
        lists = [x for x in re.split(',| ', code) if x]
        # .text, .data
        if(lists[0] == '.text'):
            self.isCode = True
        elif(lists[0] == '.data'):
            self.isCode = False
        # Data
        elif(self.isCode == False):
            assert len(lists) == 3 and lists[0][-1] == ':' and lists[1] == '.word'
            self.Data[lists[0][0:-1]] = int(lists[2])
        # Flag:
        elif(lists[0][-1] == ':'):
            self.Tags[lists[0][0:-1]] = len(self.Coding)
        # Coding
        else:
            assert lists[0] in self.CodingStart
            self.Coding.append(lists)
        return

    def ReadCodeByFile(self, DebugText, StatisticsText, ReservationText, LoadStoreText, ClockText, RegisterText, CodeText) -> bool:
        self.reset(Breakpoints={})
        self.DebugText = DebugText
        self.StatisticsText = StatisticsText
        self.ReservationText = ReservationText
        self.LoadStoreText = LoadStoreText
        self.ClockText = ClockText
        self.RegisterText = RegisterText
        self.CodeText = CodeText
        filepath = filedialog.askopenfilename(title='Choose Your File')
        self.filepath = filepath
        try:
            DebugText.insert('end', 'Loading For ' + filepath + ' ... ' + '\n\n')
            f = open(filepath, encoding='UTF-8')
            self.fileread = []
            for line in f:
                self.fileread.append(line)
                DebugText.insert('end', line.strip() + '\n')
                if(line.strip() == ''):
                    continue
                self.CheckCoding(line.strip())
            self.HistoryData.append(self.Data)
            self.HistoryRegs.append(self.Regs)
            self.HistoryTASKS.append(self.TASKS)
            DebugText.insert('end', '\nLoading Finished!' + '\n')
            self.ShowState(0)
            return True
        except:
            return False

    def EndRunning(self):
        self.endflag = True
        showinfo("Info", "The Program is Finished.")
        return
    
    def NextState(self, state: str) -> Union[str, int]:
        if(state == 'Init'):
            return '流出'
        elif(state == '流出'):
            return '执行'
        elif(state == '执行'):
            return '写结果'
        elif(state == '写结果'):
            return -1
    
    def ShowState(self, timing: int):
        # ClockText
        self.ClockText.delete('1.0', 'end')
        self.ClockText.insert("end", 'ClockText\n', "center")
        self.ClockText.insert('end', 'Instru/Cycles' + '\t\t')
        for i in range(1, timing+1, 1):
            self.ClockText.insert('end', str(i) + '\t')
        self.ClockText.insert('end', '\n')
        maxx = 0
        for i in range(1, timing+1, 1):
            for itemnum, index, state, partname in sorted(self.HistoryTASKS[i], key=lambda x:x[0]):
                if(itemnum > maxx):
                    self.ClockText.insert(str(itemnum+1+1) + '.0', ' '.join(self.Coding[index]) + '\t\t')
                    maxx = itemnum
                    for j in range(i-1):
                        self.ClockText.insert(str(itemnum+1+1) + '.end', '\t')
                    self.ClockText.insert(str(itemnum+1+1) + '.end', state + '\t\n')
                else:
                    self.ClockText.insert(str(itemnum+1+1) + '.end', state + '\t')
        # RegisterText
        self.RegisterText.delete('1.0', 'end')
        self.RegisterText.insert("end", 'RegisterText\n', "center")
        self.RegisterText.insert('end', 'Register' + '\t\t' + 'Data' + '\t\t' + 'Qi' + '\n')
        for item, num in self.HistoryRegs[timing].items():
            self.RegisterText.insert('end', item + '=\t\t0x' + ('%x' % num).rjust(8, '0') + ( ('\t\t' + str(self.Qi[item])) if (item in self.Qi and self.Qi[item] != 0) else '') + '\n')
        # CodeText
        self.CodeText.delete('1.0', 'end')
        self.CodeText.insert("end", 'CodeText\n', "center")
        State = {}
        for itemnum, index, state, partname in sorted(self.HistoryTASKS[timing], key=lambda x:x[0]):
            if str(index) in State:
                State[str(index)].append(state)
            else:
                State[str(index)] = [state]
        self.CodeText.insert('end', '$TEXT\t\tCode\t\tBreakpoints\t\tStatus' + '\n')
        for i, item in enumerate(self.Coding):
            self.CodeText.insert('end', '0x' + ('%x' % (i*4)).rjust(8, '0') + '\t\t')
            self.CodeText.insert('end', ' '.join(item) + '\t\t')
            if(str(i+1) in self.Breakpoints):
                self.CodeText.insert('end', '|'.join(self.Breakpoints[str(i+1)]) + '\t\t') 
            else:
                self.CodeText.insert('end', '\t\t')
            if(str(i) in State):
                self.CodeText.insert('end', '|'.join(State[str(i)]) + '\n') 
            else:
                self.CodeText.insert('end', '\n')
        # ReservationText
        self.ReservationText.delete('1.0', 'end')
        self.ReservationText.insert("end", 'ReservationText\n', "center")
        self.ReservationText.insert('end', 'Time\tName\tBusy\tOp\tVj\tVk\tQj\tQk' + '\n')
        for item in ['ADD', 'MUL']:
            for i in range(self.PartNum[item]):
                partname = item + str(i+1)
                IsBusy = self.RS[partname]['Busy']
                if(IsBusy == 'No'):
                    self.ReservationText.insert('end', '\t' + partname + '\tNo\n')
                else:
                    self.ReservationText.insert('end', str(self.RS[partname]['time']) + '\t' + partname + '\t' + 'Yes' + '\t' + self.RS[partname]['Op'] + '\t')
                    self.ReservationText.insert('end', (str(self.RS[partname]['Vj']) if self.RS[partname]['Qj'] == 0 else '') + '\t' + (str(self.RS[partname]['Vk']) if self.RS[partname]['Qk'] == 0 else '') + '\t' + str(self.RS[partname]['Qj']) + '\t' + str(self.RS[partname]['Qk']) + '\n')
        # LoadStoreText
        self.LoadStoreText.delete('1.0', 'end')
        self.LoadStoreText.insert("end", 'LoadStoreText\n', "center")
        self.LoadStoreText.insert('end', 'Name\tBusy\tV\tQ' + '\n')
        for item in ['LD']:
            for i in range(self.PartNum[item]):
                partname = item + str(i+1)
                IsBusy = self.RS[partname]['Busy']
                if(IsBusy == 'No'):
                    self.LoadStoreText.insert('end', partname + '\tNo\n')
                else:
                    self.LoadStoreText.insert('end', partname + '\t' + 'Yes' + '\t' + str(self.RS[partname]['Vj']) + '\t' + str(self.RS[partname]['Qj']) + '\n')
        # StatisticsText
        self.StatisticsText.delete('1.0', 'end')
        self.StatisticsText.insert("end", 'StatisticsText\n', "center")
        ## Total
        self.StatisticsText.insert('end', 'Total:' + '\n')
        self.StatisticsText.insert('end', '\t' + str(timing)+' Cycle(s) executed.' + '\n')
        self.StatisticsText.insert('end', '\tID executed by ' + str(self.Run_executed_num) + ' Instruction(s)' + '\n')
        temp_num = 0
        for itemnum, index, state, partname in sorted(self.HistoryTASKS[timing], key=lambda x:x[0]):
            if(state != 'aborted'):
                temp_num += 1
        self.StatisticsText.insert('end', '\t' + str(temp_num) + ' Instruction(s) currently in.' + '\n\n')
        ## Hardware configuration
        self.StatisticsText.insert('end', 'Hardware configuration:' + '\n')
        self.StatisticsText.insert('end', '\tfaddEX-Stages: 1, required Cycles: 6.' + '\n')
        self.StatisticsText.insert('end', '\tfmulEX-Stages: 1, required Cycles: 7.' + '\n')
        self.StatisticsText.insert('end', '\tfdivEX-Stages: 1, required Cycles: 10.' + '\n')
        ## Stalls
        self.StatisticsText.insert('end', 'Stalls:' + '\n')
        temp_num = 0
        for item, num in self.stalls.items():
            self.StatisticsText.insert('end', '\t' + item + ' stalls: ' + str(num) + ' (' + str('%.2f' % (float(num*100.0/timing) if timing != 0 else 0.0)) + '%' + ' of all Cycles).' + '\n')
            temp_num += num
        self.StatisticsText.insert('end', '\t' + 'Total stalls: ' + str(temp_num) + ' (' + str('%.2f' % (float(temp_num*100.0/timing) if timing != 0 else 0.0)) + '%' + ' of all Cycles).' + '\n')
        ## Conditional Branches
        self.StatisticsText.insert('end', 'Conditional Branches:' + '\n')
        temp_num1 = self.Conditional_Branches['taken']
        temp_num2 = self.Conditional_Branches['not taken']
        self.StatisticsText.insert('end', '\t' + 'Total: ' + str(temp_num1+temp_num2) + ' (' + str('%.2f' % (float((temp_num1+temp_num2)*100.0/timing) if timing != 0 else 0.0)) + '%' + ' of all Cycles), thereof:' + '\n')
        self.StatisticsText.insert('end', '\t\t' + 'taken: ' + str(temp_num1) + ' (' + str('%.2f' % (float(temp_num1*100.0/(temp_num1+temp_num2)) if temp_num1+temp_num2 != 0 else 0.0)) + '%' + ' of all Conditional Branches).' + '\n')
        self.StatisticsText.insert('end', '\t\t' + 'not taken: ' + str(temp_num2) + ' (' + str('%.2f' % (float(temp_num2*100.0/(temp_num1+temp_num2)) if temp_num1+temp_num2 != 0 else 0.0)) + '%' + ' of all Conditional Branches).' + '\n')
        ## Load/Store Instructions
        self.StatisticsText.insert('end', 'Load/Store Instructions:' + '\n')
        temp_num1 = self.Load_Store_Instructions['Loads']
        temp_num2 = self.Load_Store_Instructions['Stores']
        self.StatisticsText.insert('end', '\t' + 'Total: ' + str(temp_num1+temp_num2) + ' (' + str('%.2f' % (float((temp_num1+temp_num2)*100.0/timing) if timing != 0 else 0.0)) + '%' + ' of all Cycles), thereof:' + '\n')
        self.StatisticsText.insert('end', '\t\t' + 'Loads: ' + str(temp_num1) + ' (' + str('%.2f' % (float(temp_num1*100.0/(temp_num1+temp_num2)) if temp_num1+temp_num2 != 0 else 0.0)) + '%' + ' of all Load/Store Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t\t' + 'Stores: ' + str(temp_num2) + ' (' + str('%.2f' % (float(temp_num2*100.0/(temp_num1+temp_num2)) if temp_num1+temp_num2 != 0 else 0.0)) + '%' + ' of all Load/Store Instructions).' + '\n')
    
    def NextStep(self) -> bool:
        if(self.endflag or self.Coding == []):
            return False
        self.nowUsedStates = []
        self.DebugText.insert('end', 'Running For NextStep: ' + str(len(self.HistoryTASKS)) + '\n')
        newTASKS = []
        temp_task = []
        newstate = ''
        for itemnum, index, state, partname in sorted(self.TASKS, key=lambda x:x[0]):
            self.DebugText.insert('end', 'Dealing With Command: ' + ' '.join(self.Coding[index]) + ', detail: (itemnum, index, state) = (' + str(itemnum) + ', ' + str(index) + ', ' + state + ')\n')
            if(self.NextState(state) != -1):
                result = self.CodingStart[self.Coding[index][0]](index, state, partname, 0)
                if(isinstance(result, tuple)):
                    newstate, partname = result
                    newTASKS.append((itemnum, index, newstate, partname))
                    if(self.NextState(state) == newstate and newstate == '执行'):
                        if(self.Coding[index][0] == 'LD'):
                            self.Load_Store_Instructions['Loads'] += 1
                        elif(self.Coding[index][0] == 'SD'):
                            self.Load_Store_Instructions['Stores'] += 1
                else:
                    temp_task.append((itemnum, index, state, partname))
            # record
            if(newstate == self.NextState(state) and newstate == '执行'):
                self.Run_executed_num += 1
        
        if(len(self.Coding) > self.Regs['PC']):
            newstate, partname = self.CodingStart[self.Coding[self.Regs['PC']][0]](self.Regs['PC'], 'Init', '')
            if newstate == '流出':
                self.time += 1
                newTASKS.append((self.time, self.Regs['PC'], '流出', partname))
                self.Regs['PC'] += 1
        
        for itemnum, index, state, partname in sorted(temp_task, key=lambda x:-x[0]):
            self.DebugText.insert('end', 'Dealing With Command: ' + ' '.join(self.Coding[index]) + ', detail: (itemnum, index, state) = (' + str(itemnum) + ', ' + str(index) + ', ' + state + ')\n')
            if(self.NextState(state) != -1):
                result = self.CodingStart[self.Coding[index][0]](index, state, partname, 1)
                if(isinstance(result, tuple)):
                    newstate, partname = result
                    newTASKS.append((itemnum, index, newstate, partname))
        
        if(newTASKS == []):
            self.EndRunning()
        self.TASKS = newTASKS

        # if(self.endflag == False):
        self.HistoryData.append(self.Data)
        self.HistoryRegs.append(self.Regs)
        self.HistoryTASKS.append(self.TASKS)
        self.ShowState(len(self.HistoryTASKS)-1)

        # Check Breakpoints
        temp_flag = False
        temp_index = 0
        temp_state = ''
        for itemnum, index, state, partname in sorted(self.TASKS, key=lambda x:x[0]):
            if temp_flag == True:
                break
            if state == '执行' and self.RS[partname]['time'] != self.PartTime[self.RS[partname]['Op']]-1:
                continue
            for bindex, bstate in self.Breakpoints.items():
                if(index == int(bindex)-1 and state in bstate):
                    temp_flag = True
                    temp_index = index
                    temp_state = state
                    break
        if(temp_flag == True):
            showinfo("Info", "Index: " + str(temp_index+1) + ', State: ' + temp_state + ' have reached.')
            return False

        # # Print
        # self.DebugText.insert('end', 'Data: ' + '\n')
        # for item, num in self.Data.items():
        #     self.DebugText.insert('end', ' # '.join([item, str(num)]) + '\n')
        # self.DebugText.insert('end', 'Regs: ' + '\n')
        # for item, num in self.Regs.items():
        #     self.DebugText.insert('end', ' # '.join([item, str(num)]) + '\n')
        # self.DebugText.insert('end', 'TASKS: ' + '\n')
        # for itemnum, index, state in sorted(self.TASKS, key=lambda x:x[0]):
        #     self.DebugText.insert('end', ' # '.join([str(itemnum), str(index), state]) + '\n')
        return True

    def NextNStep(self):
        received = askinteger("Ask For NextNStep", "Num for Steps", initialvalue=1)
        if(isinstance(received, type(None))):
            return
        try:
            received = int(received)
        except:
            showerror("Error", "The Number is of Wrong Type!")
            return
        for i in range(received):
            if(self.NextStep() == False):
                showinfo("Info", "Break NextNStep By BreakPoints or The program is Ended!")
                return
        
    def Back(self):
        now = len(self.HistoryTASKS)-1
        self.reset_DLX()
        for i in range(now-1):
            self.NextStep()

    def Run(self):
        if(self.Coding == []):
            showerror("Error", "Nothing Can be Run, Please Load Your File First!")
            return
        while(self.endflag == False):
            if(self.NextStep() == False):
                showinfo("Info", "Break Run By BreakPoints or The program is Ended!")
                return
    
    def RunTo(self):
        received = askstring("Ask For RunTo", "Index(1~n)-State('流出', '执行', '写结果')", initialvalue='1-执行')
        if(isinstance(received, type(None))):
            return
        try:
            received = received.split('-')
            if(len(received) != 2 or int(received[0]) < 1 or int(received[0]) > len(self.Coding) or received[1] not in ['流出', '执行', '写结果']):
                showerror("Error", "The String is of Wrong Type!")
                return
            temp_flag = False
            while(self.endflag == False and temp_flag == False):
                if(self.NextStep() == False):
                    showinfo("Info", "Break RunTo By BreakPoints or The program is Ended!")
                    return
                for itemnum, index, state, partname in sorted(self.TASKS, key=lambda x:x[0]):
                    if(index == int(received[0])-1 and state == received[1]):
                        temp_flag = True
                        break
            if(temp_flag == True):
                showinfo("Info", "Index: " + str(received[0]) + ', State: ' + received[1] + ' have reached.')
            else:
                showerror("Error", "Something Wrong happened when Running!")
        except:
            showerror("Error", "Something Wrong happened when Running!")
        return

    def Set_Breakpoint(self):
        received = askstring("Ask For Set_Breakpoint", "Index(1~n)-State('流出', '执行', '写结果')", initialvalue='1-执行')
        if(isinstance(received, type(None))):
            return
        try:
            received = received.split('-')
            if(len(received) != 2 or int(received[0]) < 1 or int(received[0]) > len(self.Coding) or received[1] not in ['流出', '执行', '写结果'] or (received[0] in self.Breakpoints and received[1] in self.Breakpoints[received[0]])):
                showerror("Error", "The String is of Wrong Type!")
                return
            if(received[0] in self.Breakpoints):
                self.Breakpoints[received[0]].append(received[1])
            else:
                self.Breakpoints[received[0]] = [received[1]]
            self.ShowState(len(self.HistoryTASKS)-1)
        except:
            showerror("Error", "Something Wrong happened when Running!")
        return
    
    def LD(self, index: int, prestate: str, partname: str = '', writestate: int = 0):
        lists = self.Coding[index]
        assert lists[2] in self.Data and lists[1] in self.Regs
        if(self.NextState(prestate) == '流出'):
            for i in range(self.PartNum['LD']):
                partname = 'LD' + str(i+1)
                if(self.RS[partname]['Busy'] == 'No'):
                    break
                partname = ''
            if partname == '':
                self.stalls['Structural'] += 1
                return prestate, partname
            # first arg
            self.RS[partname]['Vj'] = lists[2]
            self.RS[partname]['Qj'] = 0
            # second arg
            self.RS[partname]['Vk'] = 0
            self.RS[partname]['Qk'] = 0
            # args
            if(self.RS[partname]['Qj'] != 0 or self.RS[partname]['Qk'] != 0):
                self.stalls['RAW'] += 1
            # other
            self.RS[partname]['Busy'] = 'Yes'
            self.RS[partname]['Op'] = 'LD'
            self.RS[partname]['time'] = self.PartTime['LD']
            self.Qi[lists[1]] = partname
            if(lists[1] in self.ReadParts):
                self.stalls['WAR'] += 1
            self.ReadParts.append(lists[2])
            return self.NextState(prestate), partname
        elif(self.RS[partname]['time'] != 0):
            self.RS[partname]['time'] = self.RS[partname]['time']-1
            if(self.RS[partname]['time'] == 0):
                self.RS[partname]['Vj'] = self.Data[self.RS[partname]['Vj']]
                self.RS[partname]['Result'] = self.RS[partname]['Vj']
            return '执行', partname
        else:
            if(writestate == 0):
                return 1
            for item in self.Qi:
                if(self.Qi[item] == partname):
                    self.Regs[item] = self.RS[partname]['Result']
                    self.Qi[item] = 0
                    break
            for item in self.RS:
                if(self.RS[item]['Qj'] == partname):
                    self.RS[item]['Vj'] = self.RS[partname]['Result']
                    self.RS[item]['Qj'] = 0
                if(self.RS[item]['Qk'] == partname):
                    self.RS[item]['Vk'] = self.RS[partname]['Result']
                    self.RS[item]['Qk'] = 0
            self.RS[partname]['Busy'] = 'No'
            return self.NextState(prestate), partname
        
    def SD(self, index: int, prestate: str, partname: str = '', writestate: int = 0):
        lists = self.Coding[index]
        assert lists[1] in self.Data and lists[2] in self.Regs
        if(self.NextState(prestate) == '流出'):
            for i in range(self.PartNum['LD']):
                partname = 'LD' + str(i+1)
                if(self.RS[partname]['Busy'] == 'No'):
                    break
                partname = ''
            if partname == '':
                self.stalls['Structural'] += 1
                return prestate, partname
            # first arg
            if(lists[2] in self.Qi and self.Qi[lists[2]] != 0):
                self.RS[partname]['Qj'] = self.Qi[lists[2]]
            else:
                self.RS[partname]['Vj'] = self.Regs[lists[2]]
                self.RS[partname]['Qj'] = 0
            # second arg
            self.RS[partname]['Vk'] = 0
            self.RS[partname]['Qk'] = 0
            # args
            if(self.RS[partname]['Qj'] != 0 or self.RS[partname]['Qk'] != 0):
                self.stalls['RAW'] += 1
            # other
            self.RS[partname]['Busy'] = 'Yes'
            self.RS[partname]['Op'] = 'SD'
            self.RS[partname]['time'] = self.PartTime['SD']
            self.Qi[lists[1]] = partname
            if(lists[1] in self.ReadParts):
                self.stalls['WAR'] += 1
            self.ReadParts.append(lists[2])
            return self.NextState(prestate), partname
        elif(self.RS[partname]['time'] != 0):
            self.RS[partname]['time'] = self.RS[partname]['time']-1
            return '执行', partname
        else:
            if(writestate == 0):
                return 1
            if(self.RS[partname]['Qj'] != 0):
                return prestate, partname
            for item in self.Qi:
                if(self.Qi[item] == partname):
                    self.Data[item] = self.RS[partname]['Result']
                    self.Qi[item] = 0
                    break
            for item in self.RS:
                if(self.RS[item]['Qj'] == partname):
                    self.RS[item]['Vj'] = self.RS[partname]['Result']
                    self.RS[item]['Qj'] = 0
                if(self.RS[item]['Qk'] == partname):
                    self.RS[item]['Vk'] = self.RS[partname]['Result']
                    self.RS[item]['Qk'] = 0
            self.RS[partname]['Busy'] = 'No'
            return self.NextState(prestate), partname
        
    def ADD(self, index: int, prestate: str, partname: str = '', writestate: int = 0):
        lists = self.Coding[index]
        assert len(lists) == 4
        for i in range(1, 4, 1):
            assert lists[i] in self.Regs
        if(self.NextState(prestate) == '流出'):
            for i in range(self.PartNum['ADD']):
                partname = 'ADD' + str(i+1)
                if(self.RS[partname]['Busy'] == 'No'):
                    break
                partname = ''
            if partname == '':
                self.stalls['Structural'] += 1
                return prestate, partname
            # first arg
            if(lists[2] in self.Qi and self.Qi[lists[2]] != 0):
                self.RS[partname]['Qj'] = self.Qi[lists[2]]
            else:
                self.RS[partname]['Vj'] = self.Regs[lists[2]]
                self.RS[partname]['Qj'] = 0
            # second arg
            if(lists[3] in self.Qi and self.Qi[lists[3]] != 0):
                self.RS[partname]['Qk'] = self.Qi[lists[3]]
            else:
                self.RS[partname]['Vk'] = self.Regs[lists[3]]
                self.RS[partname]['Qk'] = 0
            # args
            if(self.RS[partname]['Qj'] != 0 or self.RS[partname]['Qk'] != 0):
                self.stalls['RAW'] += 1
            # other
            self.RS[partname]['Busy'] = 'Yes'
            self.RS[partname]['Op'] = 'ADD'
            self.RS[partname]['time'] = self.PartTime['ADD']
            self.Qi[lists[1]] = partname
            if(lists[1] in self.ReadParts):
                self.stalls['WAR'] += 1
            self.ReadParts.append(lists[2])
            self.ReadParts.append(lists[3])
            return self.NextState(prestate), partname
        elif(self.RS[partname]['time'] != 0):
            if(self.RS[partname]['Qj'] != 0 or self.RS[partname]['Qk'] != 0):
                return '执行', partname
            self.RS[partname]['time'] = self.RS[partname]['time']-1
            if(self.RS[partname]['time'] == 0):
                self.RS[partname]['Result'] = self.RS[partname]['Vj'] + self.RS[partname]['Vk']
            return '执行', partname
        else:
            if(writestate == 0):
                return 1
            for item in self.Qi:
                if(self.Qi[item] == partname):
                    self.Regs[item] = self.RS[partname]['Result']
                    self.Qi[item] = 0
                    break
            for item in self.RS:
                if(self.RS[item]['Qj'] == partname):
                    self.RS[item]['Vj'] = self.RS[partname]['Result']
                    self.RS[item]['Qj'] = 0
                if(self.RS[item]['Qk'] == partname):
                    self.RS[item]['Vk'] = self.RS[partname]['Result']
                    self.RS[item]['Qk'] = 0
            self.RS[partname]['Busy'] = 'No'
            return self.NextState(prestate), partname
        
    def SUB(self, index: int, prestate: str, partname: str = '', writestate: int = 0):
        lists = self.Coding[index]
        assert len(lists) == 4
        for i in range(1, 4, 1):
            assert lists[i] in self.Regs
        if(self.NextState(prestate) == '流出'):
            for i in range(self.PartNum['ADD']):
                partname = 'ADD' + str(i+1)
                if(self.RS[partname]['Busy'] == 'No'):
                    break
                partname = ''
            if partname == '':
                self.stalls['Structural'] += 1
                return prestate, partname
            # first arg
            if(lists[2] in self.Qi and self.Qi[lists[2]] != 0):
                self.RS[partname]['Qj'] = self.Qi[lists[2]]
            else:
                self.RS[partname]['Vj'] = self.Regs[lists[2]]
                self.RS[partname]['Qj'] = 0
            # second arg
            if(lists[3] in self.Qi and self.Qi[lists[3]] != 0):
                self.RS[partname]['Qk'] = self.Qi[lists[3]]
            else:
                self.RS[partname]['Vk'] = self.Regs[lists[3]]
                self.RS[partname]['Qk'] = 0
            # args
            if(self.RS[partname]['Qj'] != 0 or self.RS[partname]['Qk'] != 0):
                self.stalls['RAW'] += 1
            # other
            self.RS[partname]['Busy'] = 'Yes'
            self.RS[partname]['Op'] = 'SUB'
            self.RS[partname]['time'] = self.PartTime['SUB']
            self.Qi[lists[1]] = partname
            if(lists[1] in self.ReadParts):
                self.stalls['WAR'] += 1
            self.ReadParts.append(lists[2])
            self.ReadParts.append(lists[3])
            return self.NextState(prestate), partname
        elif(self.RS[partname]['time'] != 0):
            if(self.RS[partname]['Qj'] != 0 or self.RS[partname]['Qk'] != 0):
                return '执行', partname
            self.RS[partname]['time'] = self.RS[partname]['time']-1
            if(self.RS[partname]['time'] == 0):
                self.RS[partname]['Result'] = self.RS[partname]['Vj'] - self.RS[partname]['Vk']
            return '执行', partname
        else:
            if(writestate == 0):
                return 1
            for item in self.Qi:
                if(self.Qi[item] == partname):
                    self.Regs[item] = self.RS[partname]['Result']
                    self.Qi[item] = 0
                    break
            for item in self.RS:
                if(self.RS[item]['Qj'] == partname):
                    self.RS[item]['Vj'] = self.RS[partname]['Result']
                    self.RS[item]['Qj'] = 0
                if(self.RS[item]['Qk'] == partname):
                    self.RS[item]['Vk'] = self.RS[partname]['Result']
                    self.RS[item]['Qk'] = 0
            self.RS[partname]['Busy'] = 'No'
            return self.NextState(prestate), partname
        
    def MUL(self, index: int, prestate: str, partname: str = '', writestate: int = 0):
        lists = self.Coding[index]
        assert len(lists) == 4
        for i in range(1, 4, 1):
            assert lists[i] in self.Regs
        if(self.NextState(prestate) == '流出'):
            for i in range(self.PartNum['MUL']):
                partname = 'MUL' + str(i+1)
                if(self.RS[partname]['Busy'] == 'No'):
                    break
                partname = ''
            if partname == '':
                self.stalls['Structural'] += 1
                return prestate, partname
            # first arg
            if(lists[2] in self.Qi and self.Qi[lists[2]] != 0):
                self.RS[partname]['Qj'] = self.Qi[lists[2]]
            else:
                self.RS[partname]['Vj'] = self.Regs[lists[2]]
                self.RS[partname]['Qj'] = 0
            # second arg
            if(lists[3] in self.Qi and self.Qi[lists[3]] != 0):
                self.RS[partname]['Qk'] = self.Qi[lists[3]]
            else:
                self.RS[partname]['Vk'] = self.Regs[lists[3]]
                self.RS[partname]['Qk'] = 0
            # args
            if(self.RS[partname]['Qj'] != 0 or self.RS[partname]['Qk'] != 0):
                self.stalls['RAW'] += 1
            # other
            self.RS[partname]['Busy'] = 'Yes'
            self.RS[partname]['Op'] = 'MUL'
            self.RS[partname]['time'] = self.PartTime['MUL']
            self.Qi[lists[1]] = partname
            if(lists[1] in self.ReadParts):
                self.stalls['WAR'] += 1
            self.ReadParts.append(lists[2])
            self.ReadParts.append(lists[3])
            return self.NextState(prestate), partname
        elif(self.RS[partname]['time'] != 0):
            if(self.RS[partname]['Qj'] != 0 or self.RS[partname]['Qk'] != 0):
                return '执行', partname
            self.RS[partname]['time'] = self.RS[partname]['time']-1
            if(self.RS[partname]['time'] == 0):
                self.RS[partname]['Result'] = self.RS[partname]['Vj'] * self.RS[partname]['Vk']
            return '执行', partname
        else:
            if(writestate == 0):
                return 1
            for item in self.Qi:
                if(self.Qi[item] == partname):
                    self.Regs[item] = self.RS[partname]['Result']
                    self.Qi[item] = 0
                    break
            for item in self.RS:
                if(self.RS[item]['Qj'] == partname):
                    self.RS[item]['Vj'] = self.RS[partname]['Result']
                    self.RS[item]['Qj'] = 0
                if(self.RS[item]['Qk'] == partname):
                    self.RS[item]['Vk'] = self.RS[partname]['Result']
                    self.RS[item]['Qk'] = 0
            self.RS[partname]['Busy'] = 'No'
            return self.NextState(prestate), partname
        
    def DIV(self, index: int, prestate: str, partname: str = '', writestate: int = 0):
        lists = self.Coding[index]
        assert len(lists) == 4
        for i in range(1, 4, 1):
            assert lists[i] in self.Regs
        if(self.NextState(prestate) == '流出'):
            for i in range(self.PartNum['MUL']):
                partname = 'MUL' + str(i+1)
                if(self.RS[partname]['Busy'] == 'No'):
                    break
                partname = ''
            if partname == '':
                self.stalls['Structural'] += 1
                return prestate, partname
            # first arg
            if(lists[2] in self.Qi and self.Qi[lists[2]] != 0):
                self.RS[partname]['Qj'] = self.Qi[lists[2]]
            else:
                self.RS[partname]['Vj'] = self.Regs[lists[2]]
                self.RS[partname]['Qj'] = 0
            # second arg
            if(lists[3] in self.Qi and self.Qi[lists[3]] != 0):
                self.RS[partname]['Qk'] = self.Qi[lists[3]]
            else:
                self.RS[partname]['Vk'] = self.Regs[lists[3]]
                self.RS[partname]['Qk'] = 0
            # args
            if(self.RS[partname]['Qj'] != 0 or self.RS[partname]['Qk'] != 0):
                self.stalls['RAW'] += 1
            # other
            self.RS[partname]['Busy'] = 'Yes'
            self.RS[partname]['Op'] = 'DIV'
            self.RS[partname]['time'] = self.PartTime['DIV']
            self.Qi[lists[1]] = partname
            if(lists[1] in self.ReadParts):
                self.stalls['WAR'] += 1
            self.ReadParts.append(lists[2])
            self.ReadParts.append(lists[3])
            return self.NextState(prestate), partname
        elif(self.RS[partname]['time'] != 0):
            if(self.RS[partname]['Qj'] != 0 or self.RS[partname]['Qk'] != 0):
                return '执行', partname
            self.RS[partname]['time'] = self.RS[partname]['time']-1
            if(self.RS[partname]['time'] == 0):
                self.RS[partname]['Result'] = self.RS[partname]['Vj'] / self.RS[partname]['Vk']
            return '执行', partname
        else:
            if(writestate == 0):
                return 1
            for item in self.Qi:
                if(self.Qi[item] == partname):
                    self.Regs[item] = self.RS[partname]['Result']
                    self.Qi[item] = 0
                    break
            for item in self.RS:
                if(self.RS[item]['Qj'] == partname):
                    self.RS[item]['Vj'] = self.RS[partname]['Result']
                    self.RS[item]['Qj'] = 0
                if(self.RS[item]['Qk'] == partname):
                    self.RS[item]['Vk'] = self.RS[partname]['Result']
                    self.RS[item]['Qk'] = 0
            self.RS[partname]['Busy'] = 'No'
            return self.NextState(prestate), partname