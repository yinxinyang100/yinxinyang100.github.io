import requests
import json

def add_flow(dpid, src_ip, dst_ip, in_port, out_port, priority=1):
    flow = {
        "dpid": dpid,
        "idle_timeout": 0,
        "hard_timeout": 0,
        "priority": priority,
        "match":{
            "dl_type": 2048,
            "dl_vlan": 1,
            "dl_vlan_pcp": 1,
            "in_port": in_port,
            "nw_src": src_ip,
            "nw_dst": dst_ip
        },
        "actions":[
            {
                "type":"OUTPUT",
                "port": out_port
            }
        ]
    }

    url = 'http://localhost:8080/stats/flowentry/add'
    ret = requests.post(
        url, headers={'Accept': 'application/json', 'Accept': 'application/json'}, data=json.dumps(flow))
    print(ret)

def show_path(src, dst, port_path):
    print('install waypoint path: {} -> {}'.format(src, dst))
    path = str(src) + ' -> '
    for node in port_path:
        path += '{}:s{}:{}'.format(*node) + ' -> '
    path += str(dst)
    path += '\n'
    print(path)

def install_path(src_sw, dst_sw, path):
    's18:1 -> 2:s19:3 -> 3:s20:2 -> 2:s13:3 -> 2:s21:3 -> 3:s14:2 -> 3:s10:2 -> 2:s18'
    # send flow mod
    for node in path:
        in_port, dpid, out_port = node
        add_flow(dpid, '10.0.0.0/24', '10.0.0.0/24', in_port, out_port)
        add_flow(dpid, '10.0.0.0/24', '10.0.0.0/24', out_port, in_port)
    show_path(src_sw, dst_sw, path)

if __name__ == '__main__':
    's18:1 -> 2:s19:3 -> 3:s20:2 -> 2:s13:3 -> 2:s21'
    install_path(18, 21, [(2, 19, 3), (3, 20, 2), (2, 13, 3)])
    's13:3 -> 2:s21:3 -> 3:s14:2 -> 3:s10:2 -> 2:s18:1 -> 2:s19'
    install_path(13, 19, [(2, 21, 3), (3, 14, 2), (3, 10, 2), (2, 18, 1)])