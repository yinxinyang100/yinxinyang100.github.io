# ryu-manager shortest_forward.py --observe-links
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER, DEAD_DISPATCHER, HANDSHAKE_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet
from ryu.lib.packet import ethernet, arp, ipv4
from ryu.controller import ofp_event
from ryu.topology import event
import sys
from network_awareness import NetworkAwareness
import networkx as nx
ETHERNET = ethernet.ethernet.__name__
ETHERNET_MULTICAST = "ff:ff:ff:ff:ff:ff"
ARP = arp.arp.__name__
class ShortestForward(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]
    _CONTEXTS = {
        'network_awareness': NetworkAwareness
    }

    def __init__(self, *args, **kwargs):
        super(ShortestForward, self).__init__(*args, **kwargs)
        self.network_awareness = kwargs['network_awareness']
        # self.weight = 'hop'
        self.weight = 'delay'
        self.mac_to_port = {}
        self.sw = {}
        self.path=None
        self.Record = {}
        self.last_node = None

    def add_flow(self, datapath, priority, match, actions, idle_timeout=0, hard_timeout=0):
        dp = datapath
        ofp = dp.ofproto
        parser = dp.ofproto_parser

        inst = [parser.OFPInstructionActions(ofp.OFPIT_APPLY_ACTIONS, actions)]
        mod = parser.OFPFlowMod(
            datapath=dp, priority=priority,
            idle_timeout=idle_timeout,
            hard_timeout=hard_timeout,
            match=match, instructions=inst)
        dp.send_msg(mod)
    
    # add -->
    @set_ev_cls(ofp_event.EventOFPPortStatus, MAIN_DISPATCHER)
    def port_status_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        # self.logger.info("port_status_handler: dpid: {}, datapath: {}, port: {}".format(datapath.id, datapath, msg.desc.port_no))
        if msg.reason in [ofproto.OFPPR_ADD, ofproto.OFPPR_MODIFY]:
            datapath.ports[msg.desc.port_no] = msg.desc
            # self.logger.info("port_status_handler: ADD/MODIFY: dpid: {}, datapath: {}, port: {}".format(datapath.id, datapath, msg.desc.port_no))
        elif msg.reason == ofproto.OFPPR_DELETE:
            datapath.ports.pop(msg.desc.port_no, None)
            # self.logger.info("port_status_handler: DELETE: dpid: {}, datapath: {}, port: {}".format(datapath.id, datapath, msg.desc.port_no))
        else:
            # self.logger.info("port_status_handler: ERROR: dpid: {}, datapath: {}, port: {}".format(datapath.id, datapath, msg.desc.port_no))
            return
        parser = msg.datapath.ofproto_parser

        # Note!!!
        if msg.reason in [ofproto.OFPPR_MODIFY]:
            if self.last_node != None:
                if(self.last_node != datapath.id):
                    try:
                        self.network_awareness.topo_map.remove_edge(self.last_node, datapath.id)
                    except:
                        pass
                    self.last_node = None
            else:
                self.last_node = datapath.id
        for item, port_path in self.Record:
            if item == (datapath.id, msg.desc.port_no):
                for node in port_path:
                    in_port, dpid, out_port = node
                    match = parser.OFPMatch()
                    actions = [parser.OFPActionOutput(in_port)]
                    self.delete_flow(dpid, 1, match, actions, 10, 30)
                    actions = [parser.OFPActionOutput(out_port)]
                    self.delete_flow(dpid, 1, match, actions, 10, 30)
        self.send_event_to_observers(ofp_event.EventOFPPortStateChange(datapath, msg.reason, msg.desc.port_no), datapath.state)
    
    def delete_flow(self, datapath, priority, match, actions, idle_timeout=0, hard_timeout=0):
        dp = datapath
        ofp = dp.ofproto
        parser = dp.ofproto_parser

        inst = [parser.OFPInstructionActions(ofp.OFPIT_APPLY_ACTIONS, actions)]
        mod = parser.OFPFlowMod(datapath=dp, priority=priority, command=ofp.OFPFC_DELETE, idle_timeout=idle_timeout, hard_timeout=hard_timeout, match=match, instructions=inst)
        dp.send_msg(mod)
    # <-- add

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packet_in_handler(self, ev):
        msg = ev.msg
        dp = msg.datapath
        ofp = dp.ofproto
        parser = dp.ofproto_parser

        dpid = dp.id
        in_port = msg.match['in_port']

        pkt = packet.Packet(msg.data)
        eth_pkt = pkt.get_protocol(ethernet.ethernet)
        arp_pkt = pkt.get_protocol(arp.arp)
        ipv4_pkt = pkt.get_protocol(ipv4.ipv4)

        pkt_type = eth_pkt.ethertype

        # layer 2 self-learning
        dst_mac = eth_pkt.dst
        src_mac = eth_pkt.src

        self.mac_to_port.setdefault(dpid, {}) # add
        if isinstance(arp_pkt, arp.arp):
            self.handle_arp(msg, in_port, dst_mac,src_mac, pkt,pkt_type)

        if isinstance(ipv4_pkt, ipv4.ipv4):
            self.handle_ipv4(msg, ipv4_pkt.src, ipv4_pkt.dst, pkt_type)

    def handle_arp(self, msg, in_port, dst, src, pkt, pkt_type):
    #just handle loop here
    #just like your code in exp1 mission2
        dp = msg.datapath
        ofp = dp.ofproto
        parser = dp.ofproto_parser
        # the identity of switch
        dpid = dp.id
        self.mac_to_port.setdefault(dpid, {})
        self.sw.setdefault(dpid, {})
        # self.logger.info('packet: %s %s %s %s', dpid, src, dst, in_port)
        if src not in self.sw[dpid] or dst not in self.sw[dpid][src]:
            self.sw[dpid].setdefault(src, {})
            self.sw[dpid][src][dst] = in_port
        elif in_port != self.sw[dpid][src][dst]:
            # self.logger.info("Throw the packet {} for the diff in_port: {}, {}!".format(dpid, in_port, self.sw[dpid][src][dst]))
            return
        self.mac_to_port[dpid][src] = in_port 
        if dst in self.mac_to_port[dpid]:
            out_port = self.mac_to_port[dpid][dst]
            if out_port != in_port:
                actions = [parser.OFPActionOutput(out_port)]  
                self.add_flow(dp, 1, parser.OFPMatch(eth_type=0x0800, eth_src=src, eth_dst=dst, in_port=in_port), actions, 10, 30)
                out = parser.OFPPacketOut(datapath=dp, buffer_id=msg.buffer_id, in_port=in_port, actions=actions, data=msg.data)  
                dp.send_msg(out)
                # self.logger.info("Send the packet {} for the in_port {} and out_port {}.".format(dpid, in_port, out_port))
            else:
                # self.logger.info("Throw the packet for the same port in {} and out {}!".format(in_port, out_port))
                pass
        else:
            actions = [parser.OFPActionOutput(ofp.OFPP_FLOOD)]
            out = parser.OFPPacketOut(datapath=dp, buffer_id=msg.buffer_id, in_port=in_port, actions=actions, data=msg.data)
            dp.send_msg(out)
            # self.logger.info("Flood the packet {} for the in_port {}!".format(dpid, in_port))
            

    def handle_ipv4(self, msg, src_ip, dst_ip, pkt_type):
        parser = msg.datapath.ofproto_parser

        dpid_path = self.network_awareness.shortest_path(src_ip, dst_ip,weight=self.weight)
        if not dpid_path:
            return
        
        self.path=dpid_path
        # get port path:  h1 -> in_port, s1, out_port -> h2
        port_path = []
        for i in range(1, len(dpid_path) - 1):
            in_port = self.network_awareness.link_info[(dpid_path[i], dpid_path[i - 1])]
            out_port = self.network_awareness.link_info[(dpid_path[i], dpid_path[i + 1])]
            port_path.append((in_port, dpid_path[i], out_port))
            # add -->
            self.Record[(dpid_path[i], out_port)] = port_path
            self.Record[(dpid_path[i], out_port)] = port_path
            # <-- add
        self.show_path(src_ip, dst_ip, port_path)
        # calc path delay
        # add -->
        delay = 0
        for i in range(len(port_path)-1):
            _, dpid1 ,_ = port_path[i]
            _, dpid2 ,_ = port_path[i+1]
            delay += self.network_awareness.topo_map.get_edge_data(dpid1, dpid2)['delay']
        delay = delay*1000
        self.logger.info('Path Delay: %s ms', delay)
        # <-- add
        # send flow mod
        for node in port_path:
            in_port, dpid, out_port = node
            self.send_flow_mod(parser, dpid, pkt_type, src_ip, dst_ip, in_port, out_port)
            self.send_flow_mod(parser, dpid, pkt_type, dst_ip, src_ip, out_port, in_port)

        # send packet_out
        _, dpid, out_port = port_path[-1]
        dp = self.network_awareness.switch_info[dpid]
        actions = [parser.OFPActionOutput(out_port)]
        out = parser.OFPPacketOut(
            datapath=dp, buffer_id=msg.buffer_id, in_port=in_port, actions=actions, data=msg.data)
        dp.send_msg(out)

    def send_flow_mod(self, parser, dpid, pkt_type, src_ip, dst_ip, in_port, out_port):
        dp = self.network_awareness.switch_info[dpid]
        match = parser.OFPMatch(
            in_port=in_port, eth_type=pkt_type, ipv4_src=src_ip, ipv4_dst=dst_ip)
        actions = [parser.OFPActionOutput(out_port)]
        self.add_flow(dp, 1, match, actions, 10, 30)

    def show_path(self, src, dst, port_path):
        self.logger.info('path: {} -> {}'.format(src, dst))
        path = src + ' -> '
        for node in port_path:
            path += '{}:s{}:{}'.format(*node) + ' -> '
        path += dst
        self.logger.info(path)