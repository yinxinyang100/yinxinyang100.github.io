from tkinter import filedialog, BooleanVar
from tkinter.messagebox import showerror, showinfo
from tkinter.simpledialog import askinteger, askstring
from typing import Union
import re

class Codes():
    def __init__(self, root):
        self.CodingStart = {'LW':   self.LW,
                            'SW':   self.SW,
                            'ADD':  self.ADD,
                            'SUBI': self.SUBI,
                            'BEQZ': self.BEQZ,
                            'J':    self.J}
        self.root = root
        
        self.time = 0
        self.aborted_itemnum = -1
        self.ID_executed_num = 0
        self.stalls = {
            'RAW': 0,
            'WAW': 0,
            'Structural': 0
        }
        self.Conditional_Branches = {
            'taken': 0,
            'not taken': 0
        }
        self.Load_Store_Instructions = {
            'Loads': 0,
            'Stores': 0
        }
        self.Coding = []
        self.nowUsedStates = []
        self.nowWriteData = []
        self.filepath = None
        self.fileread = []
        self.isCode = False
        self.endflag = False
        self.UsingForwarding = BooleanVar(value=True)
        self.Tags = {}
        self.Breakpoints = {}
        self.Data = {}
        self.HistoryData = []
        self.Regs = {}
        self.HistoryRegs = []
        self.TASKS = []
        self.HistoryTASKS = []

        self.DebugText = None
        self.StatisticsText = None
        self.PipelineText = None
        self.ClockText = None
        self.RegisterText = None
        self.CodeText = None
    
    def reset(self, filepath=None, fileread=[], DebugText=None, StatisticsText=None, PipelineText=None, ClockText=None, RegisterText=None, CodeText=None):
        self.time = 0
        self.aborted_itemnum = -1
        self.ID_executed_num = 0
        self.stalls = {
            'RAW': 0,
            'WAW': 0,
            'Structural': 0
        }
        self.Conditional_Branches = {
            'taken': 0,
            'not taken': 0
        }
        self.Load_Store_Instructions = {
            'Loads': 0,
            'Stores': 0
        }
        self.Coding = []
        self.nowUsedStates = []
        self.nowWriteData = []
        self.filepath = filepath
        self.fileread = fileread
        self.isCode = False
        self.endflag = False
        self.Tags = {}
        self.Breakpoints = {}
        self.Data = {}
        self.HistoryData = []
        self.Regs = {}
        self.HistoryRegs = []
        self.TASKS = []
        self.HistoryTASKS = []
        
        if self.DebugText != None:
            self.DebugText.delete('1.0', 'end')
        if self.StatisticsText != None:
            self.StatisticsText.delete('1.0', 'end')
        if self.PipelineText != None:
            self.PipelineText.delete('1.0', 'end')
        if self.ClockText != None:
            self.ClockText.delete('1.0', 'end')
        if self.RegisterText != None:
            self.RegisterText.delete('1.0', 'end')
        if self.CodeText != None:
            self.CodeText.delete('1.0', 'end')
        self.DebugText = DebugText
        self.StatisticsText = StatisticsText
        self.PipelineText = PipelineText
        self.ClockText = ClockText
        self.RegisterText = RegisterText
        self.CodeText = CodeText

        self.Regs['PC'] = 0
        for i in range(32):
            self.Regs['r'+str(i)] = 0
    
    def reset_DLX(self) -> bool:
        self.reset(self.filepath, self.fileread, self.DebugText, self.StatisticsText, self.PipelineText, self.ClockText, self.RegisterText, self.CodeText)
        try:
            self.DebugText.insert('end', 'Loading For ' + self.filepath + ' ... ' + '\n\n')
            f = self.fileread
            for line in f:
                self.DebugText.insert('end', line.strip() + '\n')
                if(line.strip() == ''):
                    continue
                self.CheckCoding(line.strip())
            self.HistoryData.append(self.Data)
            self.HistoryRegs.append(self.Regs)
            self.HistoryTASKS.append(self.TASKS)
            self.DebugText.insert('end', '\nLoading Finished!' + '\n')
            self.ShowState(0)
            return True
        except:
            return False
    
    def ChangeForwarding(self):
        self.reset_DLX()
        return

    def CheckCoding(self, code: str):
        lists = [x for x in re.split(',| ', code) if x]
        # .text, .data
        if(lists[0] == '.text'):
            self.isCode = True
        elif(lists[0] == '.data'):
            self.isCode = False
        # Data
        elif(self.isCode == False):
            assert len(lists) == 3 and lists[0][-1] == ':' and lists[1] == '.word'
            self.Data[lists[0][0:-1]] = int(lists[2])
        # Flag:
        elif(lists[0][-1] == ':'):
            self.Tags[lists[0][0:-1]] = len(self.Coding)
        # Coding
        else:
            assert lists[0] in self.CodingStart
            self.Coding.append(lists)
        return

    def ReadCodeByFile(self, DebugText, StatisticsText, PipelineText, ClockText, RegisterText, CodeText) -> bool:
        self.reset()
        self.DebugText = DebugText
        self.StatisticsText = StatisticsText
        self.PipelineText =PipelineText
        self.ClockText = ClockText
        self.RegisterText = RegisterText
        self.CodeText = CodeText
        filepath = filedialog.askopenfilename(title='Choose Your File')
        self.filepath = filepath
        try:
            DebugText.insert('end', 'Loading For ' + filepath + ' ... ' + '\n\n')
            f = open(filepath, encoding='UTF-8')
            self.fileread = []
            for line in f:
                self.fileread.append(line)
                DebugText.insert('end', line.strip() + '\n')
                if(line.strip() == ''):
                    continue
                self.CheckCoding(line.strip())
            self.HistoryData.append(self.Data)
            self.HistoryRegs.append(self.Regs)
            self.HistoryTASKS.append(self.TASKS)
            DebugText.insert('end', '\nLoading Finished!' + '\n')
            self.ShowState(0)
            return True
        except:
            return False

    def EndRunning(self):
        self.endflag = True
        showinfo("Info", "The Program is Finished.")
        return
    
    def NextState(self, state: str) -> Union[str, int]:
        if(state == 'Init'):
            return 'IF'
        elif(state == 'IF'):
            return 'ID'
        elif(state == 'ID'):
            return 'intEX'
        elif(state == 'intEX'):
            return 'MEM'
        elif(state == 'MEM'):
            return 'WB'
        elif(state == 'WB'):
            return -1
    
    def ShowState(self, timing: int):
        # ClockText
        self.ClockText.delete('1.0', 'end')
        self.ClockText.insert("end", 'ClockText\n', "center")
        self.ClockText.insert('end', 'Instru/Cycles' + '\t\t')
        for i in range(1, timing+1, 1):
            self.ClockText.insert('end', str(i) + '\t')
        self.ClockText.insert('end', '\n')
        maxx = 0
        for i in range(1, timing+1, 1):
            for itemnum, index, state in sorted(self.HistoryTASKS[i], key=lambda x:x[0]):
                if(itemnum > maxx):
                    self.ClockText.insert(str(itemnum+1+1) + '.0', ' '.join(self.Coding[index]) + '\t\t')
                    maxx = itemnum
                    for j in range(i-1):
                        self.ClockText.insert(str(itemnum+1+1) + '.end', '\t')
                    self.ClockText.insert(str(itemnum+1+1) + '.end', state + '\t\n')
                else:
                    self.ClockText.insert(str(itemnum+1+1) + '.end', state + '\t')
        # RegisterText
        self.RegisterText.delete('1.0', 'end')
        self.RegisterText.insert("end", 'RegisterText\n', "center")
        for item, num in self.HistoryRegs[timing].items():
            self.RegisterText.insert('end', item + '=\t0x' + ('%x' % num).rjust(8, '0') + '\n')
        # CodeText
        self.CodeText.delete('1.0', 'end')
        self.CodeText.insert("end", 'CodeText\n', "center")
        State = {}
        for itemnum, index, state in sorted(self.HistoryTASKS[timing], key=lambda x:x[0]):
            if str(index) in State:
                State[str(index)].append(state)
            else:
                State[str(index)] = [state]
        self.CodeText.insert('end', '$TEXT\t\tCode\t\tBreakpoints\t\tStatus' + '\n')
        for i, item in enumerate(self.Coding):
            self.CodeText.insert('end', '0x' + ('%x' % (i*4)).rjust(8, '0') + '\t\t')
            self.CodeText.insert('end', ' '.join(item) + '\t\t')
            if(str(i+1) in self.Breakpoints):
                self.CodeText.insert('end', '|'.join(self.Breakpoints[str(i+1)]) + '\t\t') 
            else:
                self.CodeText.insert('end', '\t\t')
            if(str(i) in State):
                self.CodeText.insert('end', '|'.join(State[str(i)]) + '\n') 
            else:
                self.CodeText.insert('end', '\n')
        # PipelineText
        self.PipelineText.delete('1.0', 'end')
        self.PipelineText.insert("end", 'PipelineText\n', "center")
        self.PipelineText.insert('end', 'Pipeline\t\tCode\t\t$TEXT' + '\n')
        for pipeline in ['IF', 'ID', 'intEX', 'MEM', 'WB']:
            self.PipelineText.insert('end', pipeline + '\t\t')
            for index, states in State.items():
                if(pipeline in states):
                    self.PipelineText.insert('end', ' '.join(self.Coding[int(index)]) + '\t\t')
                    self.PipelineText.insert('end', '0x' + ('%x' % (int(index)*4)).rjust(8, '0'))
            self.PipelineText.insert('end', '\n')
        # StatisticsText
        self.StatisticsText.delete('1.0', 'end')
        self.StatisticsText.insert("end", 'StatisticsText\n', "center")
        ## Total
        self.StatisticsText.insert('end', 'Total:' + '\n')
        self.StatisticsText.insert('end', '\t' + str(timing)+' Cycle(s) executed.' + '\n')
        self.StatisticsText.insert('end', '\tID executed by ' + str(self.ID_executed_num) + ' Instruction(s)' + '\n')
        temp_num = 0
        for itemnum, index, state in sorted(self.HistoryTASKS[timing], key=lambda x:x[0]):
            if(state != 'aborted'):
                temp_num += 1
        self.StatisticsText.insert('end', '\t' + str(temp_num) + ' Instruction(s) currently in Pipeline.' + '\n\n')
        ## Hardware configuration
        self.StatisticsText.insert('end', 'Hardware configuration:' + '\n')
        self.StatisticsText.insert('end', '\tfaddEX-Stages: 1, required Cycles: 6.' + '\n')
        self.StatisticsText.insert('end', '\tfmulEX-Stages: 1, required Cycles: 7.' + '\n')
        self.StatisticsText.insert('end', '\tfdivEX-Stages: 1, required Cycles: 10.' + '\n')
        self.StatisticsText.insert('end', '\tForwarding ' + ('enabled' if self.UsingForwarding.get() == True else 'disabled') + '.' + '\n\n')
        ## Stalls
        self.StatisticsText.insert('end', 'Stalls:' + '\n')
        temp_num = 0
        for item, num in self.stalls.items():
            self.StatisticsText.insert('end', '\t' + item + ' stalls: ' + str(num) + ' (' + str('%.2f' % (float(num*100.0/timing) if timing != 0 else 0.0)) + '%' + ' of all Cycles).' + '\n')
            temp_num += num
        self.StatisticsText.insert('end', '\t' + 'Total stalls: ' + str(temp_num) + ' (' + str('%.2f' % (float(temp_num*100.0/timing) if timing != 0 else 0.0)) + '%' + ' of all Cycles).' + '\n')
        ## Conditional Branches
        self.StatisticsText.insert('end', 'Conditional Branches:' + '\n')
        temp_num1 = self.Conditional_Branches['taken']
        temp_num2 = self.Conditional_Branches['not taken']
        self.StatisticsText.insert('end', '\t' + 'Total: ' + str(temp_num1+temp_num2) + ' (' + str('%.2f' % (float((temp_num1+temp_num2)*100.0/timing) if timing != 0 else 0.0)) + '%' + ' of all Cycles), thereof:' + '\n')
        self.StatisticsText.insert('end', '\t\t' + 'taken: ' + str(temp_num1) + ' (' + str('%.2f' % (float(temp_num1*100.0/(temp_num1+temp_num2)) if temp_num1+temp_num2 != 0 else 0.0)) + '%' + ' of all Conditional Branches).' + '\n')
        self.StatisticsText.insert('end', '\t\t' + 'not taken: ' + str(temp_num2) + ' (' + str('%.2f' % (float(temp_num2*100.0/(temp_num1+temp_num2)) if temp_num1+temp_num2 != 0 else 0.0)) + '%' + ' of all Conditional Branches).' + '\n')
        ## Load/Store Instructions
        self.StatisticsText.insert('end', 'Load/Store Instructions:' + '\n')
        temp_num1 = self.Load_Store_Instructions['Loads']
        temp_num2 = self.Load_Store_Instructions['Stores']
        self.StatisticsText.insert('end', '\t' + 'Total: ' + str(temp_num1+temp_num2) + ' (' + str('%.2f' % (float((temp_num1+temp_num2)*100.0/timing) if timing != 0 else 0.0)) + '%' + ' of all Cycles), thereof:' + '\n')
        self.StatisticsText.insert('end', '\t\t' + 'Loads: ' + str(temp_num1) + ' (' + str('%.2f' % (float(temp_num1*100.0/(temp_num1+temp_num2)) if temp_num1+temp_num2 != 0 else 0.0)) + '%' + ' of all Load/Store Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t\t' + 'Stores: ' + str(temp_num2) + ' (' + str('%.2f' % (float(temp_num2*100.0/(temp_num1+temp_num2)) if temp_num1+temp_num2 != 0 else 0.0)) + '%' + ' of all Load/Store Instructions).' + '\n')
    
    def NextStep(self) -> bool:
        if(self.endflag or self.Coding == []):
            return False
        Aborted_Flag = False
        newPC = -1
        self.nowUsedStates = []
        self.DebugText.insert('end', 'Running For NextStep: ' + str(len(self.HistoryTASKS)) + '\n')
        newTASKS = []
        newstate = ''
        for itemnum, index, state in sorted(self.TASKS, key=lambda x:x[0]):
            self.DebugText.insert('end', 'Dealing With Command: ' + ' '.join(self.Coding[index]) + ', detail: (itemnum, index, state) = (' + str(itemnum) + ', ' + str(index) + ', ' + state + ')\n')
            if(state == 'aborted'):
                continue
            if(self.aborted_itemnum != -1 and itemnum > self.aborted_itemnum):
                newTASKS.append((itemnum, index, 'aborted'))
                continue
            if(self.Coding[index][0] in ['BEQZ', 'J']):
                if(state == 'IF'):
                    newstate, result = self.CodingStart[self.Coding[index][0]](index, state)
                    if(newstate == 'ID'):
                        if result != -1:
                            if(self.Coding[index][0] == 'BEQZ'):
                                self.Conditional_Branches['taken'] += 1
                            newPC = result
                            Aborted_Flag = True
                            self.aborted_itemnum = itemnum
                        else:
                            if(self.Coding[index][0] == 'BEQZ'):
                                self.Conditional_Branches['not taken'] += 1
                    newTASKS.append((itemnum, index, newstate))
                elif(self.NextState(state) != -1):
                    newstate, result = self.CodingStart[self.Coding[index][0]](index, state)
                    newTASKS.append((itemnum, index, newstate))
                
            else:
                if(self.NextState(state) != -1):
                    newstate = self.CodingStart[self.Coding[index][0]](index, state)
                    newTASKS.append((itemnum, index, newstate))
                    if(self.NextState(state) == newstate and newstate == 'ID'):
                        if(self.Coding[index][0] == 'LW'):
                            self.Load_Store_Instructions['Loads'] += 1
                        elif(self.Coding[index][0] == 'SW'):
                            self.Load_Store_Instructions['Stores'] += 1
            # record
            if(newstate == self.NextState(state) and newstate == 'ID'):
                self.ID_executed_num += 1
            
            self.DebugText.insert('end', 'Showing For nowWriteData: ')
            for item in self.nowWriteData:
                self.DebugText.insert('end', item + ' ')
            self.DebugText.insert('end', '\n')
        
        if(len(self.Coding) > self.Regs['PC']):
            newstate = self.CodingStart[self.Coding[self.Regs['PC']][0]](self.Regs['PC'], 'Init')
            if (isinstance(newstate, tuple) and newstate[0] == 'IF') or newstate == 'IF':
                self.time += 1
                newTASKS.append((self.time, self.Regs['PC'], 'IF'))
                self.Regs['PC'] += 1
        if(newTASKS == []):
            self.EndRunning()
        self.TASKS = newTASKS
        if(Aborted_Flag == False):
            self.aborted_itemnum = -1
        else:
            self.Regs['PC'] = newPC

        # if(self.endflag == False):
        self.HistoryData.append(self.Data)
        self.HistoryRegs.append(self.Regs)
        self.HistoryTASKS.append(self.TASKS)
        self.ShowState(len(self.HistoryTASKS)-1)

        # Check Breakpoints
        temp_flag = False
        temp_index = 0
        temp_state = ''
        for itemnum, index, state in sorted(self.TASKS, key=lambda x:x[0]):
            if temp_flag == True:
                break
            for bindex, bstate in self.Breakpoints.items():
                if(index == int(bindex)-1 and state in bstate):
                    temp_flag = True
                    temp_index = index
                    temp_state = state
                    break
        if(temp_flag == True):
            showinfo("Info", "Index: " + str(temp_index) + ', State: ' + temp_state + ' have reached.')
            return False

        # # Print
        # self.DebugText.insert('end', 'Data: ' + '\n')
        # for item, num in self.Data.items():
        #     self.DebugText.insert('end', ' # '.join([item, str(num)]) + '\n')
        # self.DebugText.insert('end', 'Regs: ' + '\n')
        # for item, num in self.Regs.items():
        #     self.DebugText.insert('end', ' # '.join([item, str(num)]) + '\n')
        # self.DebugText.insert('end', 'TASKS: ' + '\n')
        # for itemnum, index, state in sorted(self.TASKS, key=lambda x:x[0]):
        #     self.DebugText.insert('end', ' # '.join([str(itemnum), str(index), state]) + '\n')
        return True

    def NextNStep(self):
        received = askinteger("Ask For NextNStep", "Num for Steps", initialvalue=1)
        if(isinstance(received, type(None))):
            return
        try:
            received = int(received)
        except:
            showerror("Error", "The Number is of Wrong Type!")
            return
        for i in range(received):
            if(self.NextStep() == False):
                showinfo("Info", "Break NextNStep By BreakPoints or The program is Ended!")
                return
        
    def Run(self):
        if(self.Coding == []):
            showerror("Error", "Nothing Can be Run, Please Load Your File First!")
            return
        while(self.endflag == False):
            if(self.NextStep() == False):
                showinfo("Info", "Break Run By BreakPoints or The program is Ended!")
                return
    
    def RunTo(self):
        received = askstring("Ask For RunTo", "Index(1~n)-State('IF', 'ID', 'intEX', 'MEM', 'WB')", initialvalue='1-ID')
        if(isinstance(received, type(None))):
            return
        try:
            received = received.split('-')
            if(len(received) != 2 or int(received[0]) < 1 or int(received[0]) > len(self.Coding) or received[1] not in ['IF', 'ID', 'intEX', 'MEM', 'WB']):
                showerror("Error", "The String is of Wrong Type!")
                return
            temp_flag = False
            while(self.endflag == False and temp_flag == False):
                if(self.NextStep() == False):
                    showinfo("Info", "Break RunTo By BreakPoints or The program is Ended!")
                    return
                for itemnum, index, state in sorted(self.TASKS, key=lambda x:x[0]):
                    if(index == int(received[0])-1 and state == received[1]):
                        temp_flag = True
                        break
            if(temp_flag == True):
                showinfo("Info", "Index: " + str(received[0]) + ', State: ' + received[1] + ' have reached.')
            else:
                showerror("Error", "Something Wrong happened when Running!")
        except:
            showerror("Error", "Something Wrong happened when Running!")
        return

    def Set_Breakpoint(self):
        received = askstring("Ask For Set_Breakpoint", "Index(1~n)-State('IF', 'ID', 'intEX', 'MEM', 'WB')", initialvalue='1-ID')
        if(isinstance(received, type(None))):
            return
        try:
            received = received.split('-')
            if(len(received) != 2 or int(received[0]) < 1 or int(received[0]) > len(self.Coding) or received[1] not in ['IF', 'ID', 'intEX', 'MEM', 'WB'] or (received[0] in self.Breakpoints and received[1] in self.Breakpoints[received[0]])):
                showerror("Error", "The String is of Wrong Type!")
                return
            if(received[0] in self.Breakpoints):
                self.Breakpoints[received[0]].append(received[1])
            else:
                self.Breakpoints[received[0]] = [received[1]]
            self.ShowState(len(self.HistoryTASKS)-1)
        except:
            showerror("Error", "Something Wrong happened when Running!")
        return
    
    def LW(self, index: int, prestate: str):
        lists = self.Coding[index]
        assert lists[2] in self.Data and lists[1] in self.Regs
        if(self.NextState(prestate) in self.nowUsedStates or (self.NextState(prestate) == ('ID' if(self.UsingForwarding.get() == False) else 'intEX') and lists[2] in self.nowWriteData)):
            if(self.NextState(prestate) in self.nowUsedStates):
                # self.stalls['Structural'] += 1
                pass
            else:
                self.stalls['RAW'] += 1
            self.nowUsedStates.append(prestate)
            return prestate
        else:
            self.nowUsedStates.append(self.NextState(prestate))
        if(self.NextState(prestate) == ('ID' if(self.UsingForwarding.get() == False) else 'intEX')):
            self.nowWriteData.append(lists[1])
        elif(self.NextState(prestate) == 'WB'):
            self.nowWriteData.remove(lists[1])
        if(prestate in ['Init', 'IF', 'ID', 'MEM']):
            return self.NextState(prestate)
        elif(prestate == 'intEX'):
            self.Regs[lists[1]] = self.Data[lists[2]]
        return self.NextState(prestate)
        
    def SW(self, index: int, prestate: str):
        lists = self.Coding[index]
        assert lists[1] in self.Data and lists[2] in self.Regs
        if(self.NextState(prestate) in self.nowUsedStates or (self.NextState(prestate) == ('ID' if(self.UsingForwarding.get() == False) else 'intEX') and lists[2] in self.nowWriteData)):
            if(self.NextState(prestate) in self.nowUsedStates):
                # self.stalls['Structural'] += 1
                pass
            else:
                self.stalls['RAW'] += 1
            self.nowUsedStates.append(prestate)
            return prestate
        else:
            self.nowUsedStates.append(self.NextState(prestate))
        if(self.NextState(prestate) == ('ID' if(self.UsingForwarding.get() == False) else 'intEX')):
            self.nowWriteData.append(lists[1])
        elif(self.NextState(prestate) == 'WB'):
            self.nowWriteData.remove(lists[1])
        if(prestate in ['Init', 'IF', 'ID', 'MEM']):
            return self.NextState(prestate)
        elif(prestate == 'intEX'):
            self.Data[lists[1]] = self.Regs[lists[2]]
        return self.NextState(prestate)
    def ADD(self, index: int, prestate: str):
        lists = self.Coding[index]
        assert len(lists) == 4
        for i in range(1, 4, 1):
            assert lists[i] in self.Regs
        if(self.NextState(prestate) in self.nowUsedStates or (self.NextState(prestate) == ('ID' if(self.UsingForwarding.get() == False) else 'intEX') and (lists[2] in self.nowWriteData or lists[3] in self.nowWriteData))):
            if(self.NextState(prestate) in self.nowUsedStates):
                # self.stalls['Structural'] += 1
                pass
            else:
                self.stalls['RAW'] += 1
            self.nowUsedStates.append(prestate)
            return prestate
        else:
            self.nowUsedStates.append(self.NextState(prestate))
        if(self.NextState(prestate) == ('ID' if(self.UsingForwarding.get() == False) else 'intEX')):
            self.nowWriteData.append(lists[1])
        elif(self.NextState(prestate) == ('WB' if(self.UsingForwarding.get() == False) else 'MEM')):
            self.nowWriteData.remove(lists[1])
        if(prestate in ['Init', 'IF', 'ID', 'MEM']):
            return self.NextState(prestate)
        elif(prestate == 'intEX'):
            self.Regs[lists[1]] = self.Regs[lists[2]] + self.Regs[lists[3]]
        return self.NextState(prestate)
    def SUBI(self, index: int, prestate: str):
        lists = self.Coding[index]
        assert len(lists) == 4
        for i in range(1, 3, 1):
            assert lists[i] in self.Regs
        if(self.NextState(prestate) in self.nowUsedStates or (self.NextState(prestate) == ('ID' if(self.UsingForwarding.get() == False) else 'intEX') and lists[2] in self.nowWriteData)):
            if(self.NextState(prestate) in self.nowUsedStates):
                # self.stalls['Structural'] += 1
                pass
            else:
                self.stalls['RAW'] += 1
            self.nowUsedStates.append(prestate)
            return prestate
        else:
            self.nowUsedStates.append(self.NextState(prestate))
        if(self.NextState(prestate) == ('ID' if(self.UsingForwarding.get() == False) else 'intEX')):
            self.nowWriteData.append(lists[1])
        elif(self.NextState(prestate) == ('WB' if(self.UsingForwarding.get() == False) else 'MEM')):
            self.nowWriteData.remove(lists[1])
        if(prestate in ['Init', 'IF', 'ID', 'MEM']):
            return self.NextState(prestate)
        elif(prestate == 'intEX'):
            self.Regs[lists[1]] = self.Regs[lists[2]] - int(lists[3])
        return self.NextState(prestate)
    def BEQZ(self, index: int, prestate: str) -> int:
        lists = self.Coding[index]
        assert len(lists) == 3 and lists[1] in self.Regs and lists[2] in self.Tags
        if(self.NextState(prestate) in self.nowUsedStates or (self.NextState(prestate) == 'ID' and lists[1] in self.nowWriteData)):
            if(self.NextState(prestate) in self.nowUsedStates):
                # self.stalls['Structural'] += 1
                pass
            else:
                self.stalls['RAW'] += 1
            self.nowUsedStates.append(prestate)
            return prestate, -1
        else:
            self.nowUsedStates.append(self.NextState(prestate))
        if(prestate in ['Init', 'ID', 'intEX', 'MEM']):
            return self.NextState(prestate), -1
        elif(prestate == 'IF'):
            if(self.Regs[lists[1]] == 0):
                return self.NextState(prestate), self.Tags[lists[2]]
        return self.NextState(prestate), -1
    def J(self, index: int, prestate: str) -> int:
        lists = self.Coding[index]
        assert len(lists) == 2 and lists[1] in self.Tags
        if(self.NextState(prestate) in self.nowUsedStates):
            # self.stalls['Structural'] += 1
            self.nowUsedStates.append(prestate)
            return prestate, -1
        else:
            self.nowUsedStates.append(self.NextState(prestate))
        if(prestate in ['Init', 'ID', 'intEX', 'MEM']):
            return self.NextState(prestate), -1
        elif(prestate == 'IF'):
            return self.NextState(prestate), self.Tags[lists[1]]
        return self.NextState(prestate), -1
    